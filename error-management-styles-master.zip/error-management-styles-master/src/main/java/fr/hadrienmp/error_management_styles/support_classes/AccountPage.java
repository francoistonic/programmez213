package fr.hadrienmp.error_management_styles.support_classes;

public class AccountPage {
    public static final String URL = "url de la page d'accueil";
}
